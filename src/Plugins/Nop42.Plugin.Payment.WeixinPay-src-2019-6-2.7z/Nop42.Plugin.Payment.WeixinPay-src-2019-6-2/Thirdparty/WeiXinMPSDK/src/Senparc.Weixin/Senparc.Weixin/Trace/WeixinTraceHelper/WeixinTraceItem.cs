﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Senparc.Weixin.Trace
{
   public class WeixinTraceItem
    {
        public string Title { get; set; }
        public DateTime DateTime { get; set; }

    }
}
