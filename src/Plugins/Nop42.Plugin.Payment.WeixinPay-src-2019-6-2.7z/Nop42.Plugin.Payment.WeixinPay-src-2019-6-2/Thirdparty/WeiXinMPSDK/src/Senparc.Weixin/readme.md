## Senparc.Weixin.dll 基础库

Senparc.Weixin.dll 是所有 Senparc.Weixin.[x].dll 的基础库，提供底层公用的方法和定义。
