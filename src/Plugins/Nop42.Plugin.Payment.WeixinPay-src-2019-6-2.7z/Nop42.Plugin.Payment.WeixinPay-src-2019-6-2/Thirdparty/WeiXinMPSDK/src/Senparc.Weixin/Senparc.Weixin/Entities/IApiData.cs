﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Senparc.Weixin.Entities
{
    ///// <summary>
    ///// 给打包API传递参数的接口（通常最终会以POST方式提交）。
    ///// 仅支持简单属性，不要使用数组
    ///// </summary>
    //public interface IApiData
    //{
    //}
}
